#include<stdio.h>

int calcula(int base, int exp){
	if(exp == 1){
		return base;
	}
	else{
		exp--;
		base = base * calcula(base, exp);
		return base;
	}
}

int main(){
	int base, exp;
	scanf("%d %d", &base, &exp);
	base = calcula(base, exp);
	printf("Resultado: %d\n", base);
	return 0;
}
