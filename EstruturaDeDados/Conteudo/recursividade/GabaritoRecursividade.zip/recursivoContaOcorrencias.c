#include<stdio.h>

int conta(quociente, i, k){
	if(quociente < 10){
		if(quociente == k){
			i++;
		}
		return i;
	}
	else{
		if(quociente % 10 == k){
			i++;
		}
		quociente = quociente / 10; //guarda apenas a parte inteira da divis�o por 10 em quociente
		i = conta(quociente, i, k);
		return i;
	}
}

int main(){
	int numero, oc = 0, k;
	scanf("%d", &numero);
	scanf("%d", &k);
	oc = conta(numero, oc, k);
	printf("Total de ocorrencias de %d em %d: %d.\n",k,numero, oc);
	return 0;
}
