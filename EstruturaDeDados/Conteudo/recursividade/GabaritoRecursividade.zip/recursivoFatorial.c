#include<stdio.h>

int fatorial(num){
	if(num == 1){
		return num;
	}
	else{
		num = num * fatorial(num-1);
	}
}

int main(){
	int numero;
	scanf("%d", &numero);
	numero = fatorial(numero);
	printf("%d\n", numero);
	return 0;
}
