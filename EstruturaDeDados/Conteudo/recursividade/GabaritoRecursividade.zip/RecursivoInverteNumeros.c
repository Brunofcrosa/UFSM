#include<stdio.h>
#include<math.h>

int contaDigitos(int n){
	int i = 0;
	while (n > 10){
		n = n / 10;
		i++;
	}
	printf("Total de digitos: %d\n", i+1);
	return i;	
}

int inverte(int quo, int i){
	if (i == 0){
		return quo;
	}
	else{
		int novo = (quo % 10) * pow(10, i);
		i--;
		quo = quo / 10;
		novo = novo + inverte(quo, i);
		return novo;
	}
}

int main(){
	int num, i;
	scanf("%d", &num);
	i = contaDigitos(num);
	num = inverte(num, i);
	printf("Numero invertido: %d\n", num);
	return 0;
}
